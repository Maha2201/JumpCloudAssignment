JC_TestPlan_Mahalakshmi.doc
1.This document covers highlevel overview of modules/endpoints to be tested and mapping of actual test cases to different modules
2.Document also covers Automation approach used to test the application

JC_TestCases&Execution
This Excel has various tabs as follows:
1. Summary - Test execution results
2. Test Cases - Test cases drafted with steps, description and expected result
3. Pre-requisite - Test Logs of pre-requisites 
4. Test Execution - Test Logs of all test cases(except which got blocked)

JCBatch.Bat
Batch file which contains all commands while performing Automation test
(Contents needs to be modified once identified bugs are fixed)
